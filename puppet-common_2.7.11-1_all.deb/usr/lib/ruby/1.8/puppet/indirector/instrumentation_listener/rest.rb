require 'puppet/indirector/instrumentation_listener'
require 'puppet/indirector/rest'

class Puppet::Indirector::InstrumentationListener::Rest < Puppet::Indirector::REST
end
