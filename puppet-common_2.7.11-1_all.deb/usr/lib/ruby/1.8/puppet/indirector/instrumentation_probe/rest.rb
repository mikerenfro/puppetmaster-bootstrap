require 'puppet/indirector/rest'
require 'puppet/indirector/instrumentation_probe'

class Puppet::Indirector::InstrumentationProbe::Rest < Puppet::Indirector::REST
end
