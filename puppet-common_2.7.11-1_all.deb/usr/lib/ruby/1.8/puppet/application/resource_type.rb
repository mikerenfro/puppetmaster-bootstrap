require 'puppet/application/indirection_base'

class Puppet::Application::Resource_type < Puppet::Application::IndirectionBase
end
