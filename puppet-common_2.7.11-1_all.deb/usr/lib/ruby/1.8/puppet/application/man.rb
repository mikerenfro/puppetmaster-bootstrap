require 'puppet/application/face_base'

class Puppet::Application::Man < Puppet::Application::FaceBase
end
