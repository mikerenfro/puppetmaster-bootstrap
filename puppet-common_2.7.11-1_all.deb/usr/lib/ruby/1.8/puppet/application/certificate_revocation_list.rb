require 'puppet/application/indirection_base'

class Puppet::Application::Certificate_revocation_list < Puppet::Application::IndirectionBase
end
