require 'puppet/application/face_base'

class Puppet::Application::Ca < Puppet::Application::FaceBase
  run_mode :master
end
