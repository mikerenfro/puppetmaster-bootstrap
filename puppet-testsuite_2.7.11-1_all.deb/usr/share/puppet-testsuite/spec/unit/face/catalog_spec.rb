#!/usr/bin/env rspec
require 'spec_helper'
require 'puppet/face'

describe Puppet::Face[:catalog, '0.0.1'] do
  it "should actually have some testing..."
end
